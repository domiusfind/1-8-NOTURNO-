window.onload = function () {
  const usuario = localStorage.getItem("usuario");
  const cargo = localStorage.getItem("cargo");

  document.getElementById("nomeUsuario").innerText = usuario;
  document.getElementById("cargoUsuario").innerText = cargo;

  if (cargo === "dono") {
    document.getElementById("areaDono").style.display = "block";
  }

  fetch('data/avisos.json')
    .then(response => response.json())
    .then(data => {
      const avisoDiv = document.getElementById("avisos");
      data.avisos.forEach(aviso => {
        const p = document.createElement("p");
        p.textContent = `• ${aviso}`;
        avisoDiv.appendChild(p);
      });
    });
};

function criarLogin() {
  const novoUsuario = document.getElementById("novoUsuario").value;
  const novaSenha = document.getElementById("novaSenha").value;

  alert(`Login criado: ${novoUsuario} | Senha: ${novaSenha} (Simulado)`);
}